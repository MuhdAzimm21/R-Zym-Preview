chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
        id: "previewFileSidePanel",
        title: "Preview Link (Side Panel)",
        contexts: ["link"]
    });
    chrome.contextMenus.create({
        id: "previewFileTab",
        title: "Preview Link (New Tab)",
        contexts: ["link"]
    });

    // CORS BYPASS: Inject header into all responses
    chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: [1],
        addRules: [{
            id: 1,
            priority: 1,
            action: {
                type: 'modifyHeaders',
                responseHeaders: [
                    { header: 'Access-Control-Allow-Origin', operation: 'set', value: '*' },
                    { header: 'Access-Control-Allow-Methods', operation: 'set', value: 'GET, POST, OPTIONS' },
                    { header: 'Access-Control-Allow-Headers', operation: 'set', value: '*' }
                ]
            },
            condition: {
                urlFilter: '*',
                resourceTypes: ['xmlhttprequest', 'main_frame', 'sub_frame', 'image', 'other']
            }
        }]
    });
});

function getViewerUrl(url, type = "") {
    let viewerUrl = chrome.runtime.getURL("viewer.html") + "?file=" + encodeURIComponent(url);
    if (type) viewerUrl += "&type=" + encodeURIComponent(type);
    return viewerUrl;
}

const MIME_MAP = {
    'application/pdf': 'pdf',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
    'application/vnd.ms-excel': 'xlsx',
    'text/csv': 'csv',
    'text/plain': 'txt',
    'application/json': 'json',
    'application/zip': 'zip',
    'image/png': 'png',
    'image/jpeg': 'jpg',
    'image/gif': 'gif'
};

async function sniffFileType(url) {
    try {
        const response = await fetch(url);
        const contentType = response.headers.get('Content-Type')?.split(';')[0];
        const contentDisp = response.headers.get('Content-Disposition');
        
        if (contentDisp && contentDisp.includes('filename=')) {
            const match = contentDisp.match(/filename="?([^";]+)"?/);
            if (match && match[1]) {
                const ext = match[1].split('.').pop().toLowerCase();
                if (ext) return ext;
            }
        }
        if (contentType && MIME_MAP[contentType]) return MIME_MAP[contentType];
    } catch (e) {
        console.error("Sniffing failed:", e);
    }
    return null;
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
    const url = info.linkUrl;
    if (info.menuItemId === "previewFileTab") {
        chrome.tabs.create({ url: getViewerUrl(url) });
    } else if (info.menuItemId === "previewFileSidePanel") {
        chrome.sidePanel.setOptions({
            tabId: tab.id,
            path: getViewerUrl(url),
            enabled: true
        });
        chrome.sidePanel.open({ tabId: tab.id }).catch(() => {
            chrome.tabs.create({ url: getViewerUrl(url) });
        });
    }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "preview" && sender.tab) {
        chrome.sidePanel.setOptions({
            tabId: sender.tab.id,
            path: getViewerUrl(message.url),
            enabled: true
        });
        chrome.sidePanel.open({ tabId: sender.tab.id });
    }
    
    if (message.action === "sniffType") {
        sniffFileType(message.url).then(type => sendResponse({ type }));
        return true;
    }

    if (message.action === "fetchData") {
        fetch(message.url)
            .then(async (response) => {
                if (!response.ok) throw new Error("HTTP error " + response.status);
                const buffer = await response.arrayBuffer();
                const base64 = btoa(
                    new Uint8Array(buffer).reduce((data, byte) => data + String.fromCharCode(byte), '')
                );
                sendResponse({ data: base64 });
            })
            .catch(error => {
                sendResponse({ error: error.message });
            });
        return true;
    }
});
