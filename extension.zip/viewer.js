const params = new URLSearchParams(window.location.search);
const fileUrl = params.get("file");
const viewerContainer = document.getElementById("viewer");
const viewer = document.getElementById("viewer-content");
const filenameEl = document.getElementById("filename");
const copyBtn = document.getElementById("copy-btn");
const zoomInBtn = document.getElementById("zoom-in");
const zoomOutBtn = document.getElementById("zoom-out");
const zoomLevelEl = document.getElementById("zoom-level");

let currentContent = "";
let zoomLevel = 1.0;

// Hide copy button by default
copyBtn.style.display = "none";

copyBtn.onclick = () => {
    navigator.clipboard.writeText(currentContent).then(() => {
        const originalText = copyBtn.textContent;
        copyBtn.textContent = "Copied!";
        setTimeout(() => copyBtn.textContent = originalText, 2000);
    });
};

function showCopyBtn(text) {
    currentContent = text;
    copyBtn.style.display = "block";
}

/* ---------------- ZOOM LOGIC ---------------- */
function updateZoom() {
    viewer.style.transform = `scale(${zoomLevel})`;
    zoomLevelEl.textContent = `${Math.round(zoomLevel * 100)}%`;
}

zoomInBtn.onclick = () => {
    if (zoomLevel < 3.0) {
        zoomLevel += 0.1;
        updateZoom();
    }
};

zoomOutBtn.onclick = () => {
    if (zoomLevel > 0.5) {
        zoomLevel -= 0.1;
        updateZoom();
    }
};

/* ---------------- KEYBOARD SHORTCUTS ---------------- */
window.addEventListener('keydown', (e) => {
    if (e.key === '=' || e.key === '+') zoomInBtn.click();
    if (e.key === '-') zoomOutBtn.click();
    if ((e.ctrlKey || e.metaKey) && e.key === 'c') {
        if (copyBtn.style.display !== 'none' && !window.getSelection().toString()) {
            copyBtn.click();
        }
    }
    if (e.key === 'Escape') {
        zoomLevel = 1.0;
        updateZoom();
    }
});

/* ---------------- DRAG TO PAN ---------------- */
let isDragging = false;
let startX, startY, scrollLeft, scrollTop;

viewerContainer.addEventListener('mousedown', (e) => {
    if (zoomLevel <= 1.0) return;
    isDragging = true;
    startX = e.pageX - viewerContainer.offsetLeft;
    startY = e.pageY - viewerContainer.offsetTop;
    scrollLeft = viewerContainer.scrollLeft;
    scrollTop = viewerContainer.scrollTop;
});

viewerContainer.addEventListener('mouseleave', () => { isDragging = false; });
viewerContainer.addEventListener('mouseup', () => { isDragging = false; });

viewerContainer.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    e.preventDefault();
    const x = e.pageX - viewerContainer.offsetLeft;
    const y = e.pageY - viewerContainer.offsetTop;
    const walkX = (x - startX) * 1.5;
    const walkY = (y - startY) * 1.5;
    viewerContainer.scrollLeft = scrollLeft - walkX;
    viewerContainer.scrollTop = scrollTop - walkY;
});

// Proxy fetch through background script to avoid CORS
async function fetchViaBackground(url) {
    return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ action: "fetchData", url: url }, response => {
            if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
            if (response.error) return reject(new Error(response.error));
            try {
                const binary = atob(response.data);
                const bytes = new Uint8Array(binary.length);
                for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
                resolve(bytes.buffer);
            } catch (e) { reject(new Error("Failed to decode data: " + e.message)); }
        });
    });
}

const SUPPORTED_EXTS = {
    pdf: previewPDF,
    docx: previewDOCX,
    xlsx: previewExcel, xls: previewExcel, csv: previewExcel,
    png: previewImage, jpg: previewImage, jpeg: previewImage, gif: previewImage,
    zip: previewZip,
    txt: previewCode, json: previewCode, md: previewCode, js: previewCode, css: previewCode, html: previewCode, py: previewCode, java: previewCode, cpp: previewCode, c: previewCode, h: previewCode, cs: previewCode, go: previewCode
};

async function main() {
    if (!fileUrl) {
        viewer.innerHTML = "<div class='loader'>No file provided</div>";
        return;
    }

    const name = fileUrl.split('/').pop().split('?')[0];
    filenameEl.textContent = decodeURIComponent(name);

    let ext = params.get("type") || name.split('.').pop().toLowerCase();

    // If extension is missing or not supported, try sniffing
    if (!SUPPORTED_EXTS[ext]) {
        viewer.innerHTML = "<div class='loader'>Identifying file type...</div>";
        const response = await new Promise(resolve => {
            chrome.runtime.sendMessage({ action: "sniffType", url: fileUrl }, resolve);
        });
        if (response && response.type) ext = response.type;
    }

    if (SUPPORTED_EXTS[ext]) {
        SUPPORTED_EXTS[ext](fileUrl);
    } else {
        viewer.innerHTML = "<div class='loader'>File type not supported</div>";
    }
}

main();

/* ---------------- PREVIEW FUNCTIONS ---------------- */

function previewCode(url) {
    fetchViaBackground(url)
        .then(buffer => {
            const text = new TextDecoder().decode(buffer);
            showCopyBtn(text);
            const ext = url.split('.').pop().toLowerCase();
            let lang = 'clike';
            if (['js', 'json'].includes(ext)) lang = 'javascript';
            if (['html', 'xml', 'svg'].includes(ext)) lang = 'markup';
            if (ext === 'css') lang = 'css';
            if (ext === 'json') lang = 'json';

            const pre = document.createElement("pre");
            pre.className = `language-${lang}`;
            const code = document.createElement("code");
            code.className = `language-${lang}`;
            code.textContent = text;
            pre.appendChild(code);
            viewer.innerHTML = "";
            viewer.appendChild(pre);
            if (window.Prism) Prism.highlightElement(code);
        })
        .catch(err => { viewer.innerHTML = "<div class='loader'>Error loading file: " + err.message + "</div>"; });
}

function previewZip(url) {
    fetchViaBackground(url)
        .then(data => JSZip.loadAsync(data))
        .then(zip => {
            viewer.innerHTML = "<h3>Archive Contents</h3>";
            const container = document.createElement("div");
            container.className = "table-container";
            const table = document.createElement("table");
            table.innerHTML = "<tr><th>Name</th><th>Size</th><th>Date</th></tr>";
            zip.forEach((relativePath, file) => {
                const row = table.insertRow();
                row.insertCell(0).textContent = relativePath;
                row.insertCell(1).textContent = file.dir ? "-" : formatSize(file._data.uncompressedSize || 0);
                row.insertCell(2).textContent = file.date.toLocaleString();
            });
            container.appendChild(table);
            viewer.appendChild(container);
        })
        .catch(err => { viewer.innerHTML = "<div class='loader'>Error reading ZIP: " + err.message + "</div>"; });
}

function formatSize(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function previewImage(url) {
    viewer.innerHTML = `<img src="${url}" style="max-width:100%">`;
}

function previewPDF(url) {
    pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('libs/pdf.worker.js');
    fetchViaBackground(url)
        .then(buffer => pdfjsLib.getDocument({ data: new Uint8Array(buffer) }).promise)
        .then(async function(pdf) {
            viewer.innerHTML = "";
            for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
                const page = await pdf.getPage(pageNum);
                const pageContainer = document.createElement("div");
                pageContainer.className = "pdf-page-container";
                viewer.appendChild(pageContainer);
                const canvas = document.createElement("canvas");
                canvas.style.width = "100%"; 
                canvas.style.height = "auto";
                canvas.style.display = "block";
                pageContainer.appendChild(canvas);
                const context = canvas.getContext("2d");
                const viewport = page.getViewport({ scale: 2.0 });
                canvas.height = viewport.height;
                canvas.width = viewport.width;
                await page.render({ canvasContext: context, viewport: viewport }).promise;
                const textContent = await page.getTextContent();
                const textLayerDiv = document.createElement("div");
                textLayerDiv.className = "textLayer";
                pageContainer.appendChild(textLayerDiv);
                pdfjsLib.renderTextLayer({ textContent, container: textLayerDiv, viewport, textDivs: [] });
            }
        })
        .catch(err => { viewer.innerHTML = "<div class='loader'>Error loading PDF: " + err.message + "</div>"; });
}

function previewDOCX(url) {
    fetchViaBackground(url)
        .then(buffer => {
            mammoth.extractRawText({ arrayBuffer: buffer }).then(result => showCopyBtn(result.value));
            mammoth.convertToHtml({ arrayBuffer: buffer })
                .then(result => { viewer.innerHTML = `<div class="docx-content">${result.value}</div>`; })
                .catch(err => { viewer.innerHTML = "<div class='loader'>Error loading DOCX: " + err.message + "</div>"; });
        });
}

function previewExcel(url) {
    fetchViaBackground(url)
        .then(data => {
            const workbook = XLSX.read(data);
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            showCopyBtn(XLSX.utils.sheet_to_csv(sheet));
            viewer.innerHTML = `<div class="table-container">${XLSX.utils.sheet_to_html(sheet)}</div>`;
        });
}
