console.log("Universal File Previewer: Context Menu Only Mode Active");

// This script now only serves to maintain the extension's presence on the page.
// The primary activation is through the Right-Click Context Menu.

function isPreviewable(url) {
    return !!url && !!url.match(/\.(pdf|docx|xlsx|png|jpg|jpeg|gif|txt|json|md|js|css|html|py|java|cpp|c|h|cs|go|zip)$/i);
}

// No more click interceptors here.
// This prevents any conflict with native browser behavior or site scripts.
